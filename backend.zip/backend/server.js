const express = require('express');
const mysql = require('mysql2');
const cors = require('cors');
const bcrypt = require('bcrypt');
const jwt = require('jsonwebtoken'); // For token generation
require('dotenv').config();

const app = express();
app.use(express.json());
app.use(cors());

const port = 5000;

// Database connection
const dbConfig = {
  host: 'localhost',
  user: 'root',
  password: 'root',
};

// Connect to MySQL
const db = mysql.createConnection(dbConfig);

// Connect to MySQL and create the database and tables if they don't exist
db.connect((err) => {
  if (err) {
    console.error('Error connecting to MySQL:', err);
    return;
  }
  console.log('Connected to MySQL');

  // Create database if it doesn't exist
  db.query('CREATE DATABASE IF NOT EXISTS flight_db', (err) => {
    if (err) {
      console.error('Error creating database:', err);
      return; // Exit if database creation fails
    }
    console.log('Database created or exists already.');

    // Switch to the new database
    db.changeUser({ database: 'flight_db' }, (err) => {
      if (err) {
        console.error('Error changing database:', err);
        return; // Exit if changing database fails
      }

      // Create users table if it doesn't exist
      db.query(`
        CREATE TABLE IF NOT EXISTS users (
          id INT AUTO_INCREMENT PRIMARY KEY,
          name VARCHAR(255),
          email VARCHAR(255) UNIQUE,
          password VARCHAR(255)
        )`, (err) => {
        if (err) {
          console.error('Error creating users table:', err);
          return; // Exit if users table creation fails
        }
        console.log('Users table created or exists already.');
      });

      // Create bookings table if it doesn't exist
      db.query(`
        CREATE TABLE IF NOT EXISTS bookings (
          id INT AUTO_INCREMENT PRIMARY KEY,
          name VARCHAR(255),
          email VARCHAR(255),
          flightNumber VARCHAR(255)
        )`, (err) => {
        if (err) {
          console.error('Error creating bookings table:', err);
          return; // Exit if bookings table creation fails
        }
        console.log('Bookings table created or exists already.');
      });

      // Create flights table if it doesn't exist
      // Create flights table if it doesn't exist
db.query(`
  CREATE TABLE IF NOT EXISTS flights (
    id INT AUTO_INCREMENT PRIMARY KEY,
    flightNumber VARCHAR(255),
    companyName VARCHAR(255),     // New column for flight company name
    departure VARCHAR(255),
    destination VARCHAR(255),
    flightDate DATE,
    flight_time DATETIME,
    seats INT
  )`, (err) => {
  if (err) {
    console.error('Error creating flights table:', err);
    return; // Exit if flights table creation fails
  }
  console.log('Flights table created or exists already.');
});


// Route to handle user signup
app.post('/api/signup', async (req, res) => {
  const { name, email, password } = req.body;

  // Hash the password
  const hashedPassword = await bcrypt.hash(password, 10);

  const query = 'INSERT INTO users (name, email, password) VALUES (?, ?, ?)';
  db.query(query, [name, email, hashedPassword], (err) => {
    if (err) {
      console.error('Error signing up:', err);
      return res.status(500).json({ message: 'Signup failed! Email might already be in use.' });
    }
    res.status(201).json({ message: 'User created successfully!' });
  });
});

// Route to handle user login
app.post('/api/login', (req, res) => {
  const { email, password } = req.body;

  const query = 'SELECT * FROM users WHERE email = ?';
  db.query(query, [email], async (err, results) => {
    if (err) {
      console.error('Error logging in:', err);
      return res.status(500).json({ message: 'Login failed!' });
    }
    if (results.length === 0) {
      return res.status(401).json({ message: 'Incorrect username or password!' });
    }

    const user = results[0];
    const isMatch = await bcrypt.compare(password, user.password);

    if (isMatch) {
      // Create JWT token
      const token = jwt.sign({ id: user.id }, process.env.JWT_SECRET, { expiresIn: '1h' });
      return res.status(200).json({ message: 'Login successful!', token });
    } else {
      return res.status(401).json({ message: 'Incorrect username or password!' });
    }
  });
});

// Route to get available flights based on "from", "to", and "date"
app.post('/api/search-flights', (req, res) => {
  const { from, to, date } = req.body;

  const query = `
    SELECT * FROM flights 
    WHERE departure = ? AND destination = ? AND flightDate = ?`;
  db.query(query, [from, to, date], (err, results) => {
    if (err) {
      console.error('Error fetching flights:', err);
      res.status(500).send('Error fetching flights.');
    } else if (results.length > 0) {
      res.status(200).json(results);
    } else {
      res.status(404).json({ message: 'No flights found for the given details.' });
    }
  });
});

// Route to handle flight booking
app.post('/api/bookings', (req, res) => {
  const { name, email, flightNumber } = req.body;

  const query = 'INSERT INTO bookings (name, email, flightNumber) VALUES (?, ?, ?)';
  db.query(query, [name, email, flightNumber], (err) => {
    if (err) {
      console.error('Error booking flight:', err);
      res.status(500).send('Error booking flight.');
    } else {
      res.status(200).json({ message: 'Flight booked successfully!' });
    }
  });
});

app.listen(port, () => {
  console.log(`Server is running on port ${port}`);
});
